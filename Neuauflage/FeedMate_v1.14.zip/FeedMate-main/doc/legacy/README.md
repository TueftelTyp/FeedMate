# FeedMate
make feeding you Pet smart 
---
[![License](https://img.shields.io/badge/License-CC--BY--NC--SA--4.0-c38041?style=flat&labelColor=555555)](https://github.com/TueftelTyp/FeedMate/blob/main/LICENSE) [![Made for](https://img.shields.io/badge/Made%20for-ESPHome-4168c3?style=flat&labelColor=66a861)](https://esphome.io/) [![Try](https://img.shields.io/badge/Try-Demo-42c44a?style=flat&labelColor=555555)](https://tuefteltyp.github.io/demo/feedmate.html)
---

