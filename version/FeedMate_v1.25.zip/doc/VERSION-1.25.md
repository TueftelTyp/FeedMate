# FeedMate v1.25

v1.25 korrigiert drei Abläufe, die bei der Prüfung der aktiven Oberfläche und
Firmware auffielen:

- Das zeitbasierte `/api/feed` stoppt nach der angeforderten Laufzeit. Ein
  aktivierter Hall-Sensor überwacht weiterhin fehlende Impulse und das
  Umdrehungslimit, beendet den zeitbasierten Probelauf aber nicht beim normalen
  Portionsziel.
- Die Smartphone-Kalibrierung wartet auf den tatsächlichen Abschluss und zeigt
  Motor-, Sensor-, Speicher- und Zeitfehler an.
- Beim Verteilen eines gemeinsamen Zeitplans wird auch eine leere Liste an
  gekoppelte Automaten geschickt, um dort nicht mehr gewünschte Zeiten zu
  entfernen. Reservierungen für bereits ausgeführte Slots folgen beim Sortieren
  den Fütterungsdaten statt der Position in der Liste.

Die AP-Statusanzeige wurde mit dem von der Firmware bekannten Zustand und der
Clientzahl verbunden. Dieser Softwarewert bestätigt keinen Funk-Beacon. Beim
aktuell gemeldeten ESP32-C3 sieht die serielle Ausgabe den Treiberzustand als
gestartet, während kein Smartphone oder anderes Gerät den AP findet; eine
Funk-/Antennenprüfung am konkreten Board bleibt daher erforderlich.
