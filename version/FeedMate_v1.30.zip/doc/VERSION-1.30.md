# FeedMate v1.30

Einstellungsänderungen werden selektiv übertragen; unveränderte MQTT- oder Portionswerte blockieren nicht mehr das Speichern einer Zeitzone oder eines Hostnamens.