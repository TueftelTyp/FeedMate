# FeedMate v1.16

v1.16 erweitert FeedMate um ESP32-C3, ESP32-C6, ESP32-S2 und ESP32-S3. Für Espressif-Referenz-DevKits stehen fertige PlatformIO-Umgebungen und Pinprofile bereit. Andere Boardlayouts derselben Chipfamilien können sämtliche FeedMate-GPIOs über dokumentierte Build-Flags überschreiben. ESP32-WROOM/DevKit und ESP8266 bleiben kompatibel.
