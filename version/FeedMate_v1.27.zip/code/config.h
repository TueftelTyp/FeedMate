#ifndef CONFIG_H
#define CONFIG_H

#include "platform.h"
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <LittleFS.h>
#include <Wire.h>
#include <RTClib.h>
#include <time.h>
#include <sys/time.h>
#include "logic.h"
#include <WiFiUdp.h>

// Fixed first-start credentials requested for a smartphone-only setup.
// The admin password should be changed after the first login.
static constexpr const char* INITIAL_AP_PASSWORD = "feedmate";
static constexpr const char* INITIAL_ADMIN_PASSWORD = "FeedMateAdmin";

// ============================================================================
// PIN DEFINITIONS
// ============================================================================
// Platform-specific pins and network types are defined in platform.h.

// ============================================================================
// MOTOR SETTINGS
// ============================================================================
#define MOTOR_DEFAULT_DURATION_MS   3000
#define MOTOR_MAX_DURATION_MS       30000
#define JAM_CHECK_INTERVAL_MS       100
#define JAM_DEBOUNCE_MS             500

// ============================================================================
// WIFI & MQTT
// ============================================================================
#define WIFI_HOSTNAME           "feedmate"
#define MQTT_PORT               1883
#define FEEDMATE_KEEPALIVE      30

// ============================================================================
// STORAGE
// ============================================================================
#define CONFIG_FILE             "/config.json"
#define SCHEDULE_FILE           "/schedule.json"
#define LOG_FILE                "/events.log"
#define FOODS_FILE              "/foods.json"
#define HTML_FILE               "/index.html"
#define MAX_LOG_ENTRIES         100

// ============================================================================
// EVENT TYPES (Muss mit HTML übereinstimmen!)
// ============================================================================
enum EventType {
    EVT_FEEDING_OK = 0,
    EVT_FEEDING_JAM,
    EVT_WATCHDOG_RESET,
    EVT_WIFI_DISCONNECT,
    EVT_WIFI_CONNECT,
    EVT_LOW_BATTERY,
    EVT_POWER_OUTAGE,
    EVT_POWER_RESTORED,
    EVT_MANUAL_FEED,
    EVT_UPDATE_AVAILABLE,
    EVT_DEVICE_SYNC,
    EVT_SENSOR_LOW_FOOD, EVT_FEEDING_STARTED, EVT_FEEDING_ABORTED, EVT_BOOT, EVT_STORAGE_ERROR
};

// ============================================================================
// DATA STRUCTURES
// ============================================================================
struct FeedingSlot {
    bool active;
    uint8_t hour;
    uint8_t minute;
    uint8_t second;
    uint16_t durationMs;
    uint32_t lastRunDate;
    char foodName[33];
    float portionGrams;
};

struct LogEntry {
    uint32_t timestamp;
    uint32_t uptime;
    uint8_t eventType;
    char message[64];
};

struct FeedMateConfig {
    // WiFi
    char wifiSsid[33];
    char wifiPassword[65];
    
    // MQTT
    char mqttServer[65];
    uint16_t mqttPort;
    char mqttUser[33];
    char mqttPassword[65];
    char mqttPrefix[33];
    bool mqttEnabled;
    bool haDiscovery;
    
    // Motor & Sensors
    uint16_t jamThreshold;
    uint16_t jamTimeout;
    bool lightBarrierEnabled;
    uint8_t lightBarrierThreshold;
    bool endSwitchEnabled;
    uint8_t rotationsPerPortion;
    uint8_t maxRotations;
    
    // System
    uint16_t deepSleepMinutes;
    char timezone[33];
    char adminPassword[65];  // SHA256 Hash
    char deviceName[33];
    char fleetKeyHash[65];
    
    // SMTP
    char smtpServer[65];
    uint16_t smtpPort;
    char smtpUser[33];
    char smtpPassword[65];
    char smtpFrom[65];
    uint8_t smtpEncryption;  // 0=None, 1=TLS, 2=SSL
    
    // Notifications
    char discordUrl[128];
    char pushoverToken[65];
    char pushoverUser[65];
    char telegramToken[65];
    char telegramChat[65];
    char emailAddr[65];
    bool notifyDiscord[12];
    bool notifyPushover[12];
    bool notifyTelegram[12];
    bool notifyEmail[12];
    
    // Updates
    char updateSource[16];  // github, codeberg, custom
    char customRepoUrl[128];
    bool autoUpdateCheck;
    uint8_t updateInterval;
    bool updateNotify;
    bool autoInstall;
    
    // Logging
    uint8_t logRetention;
    bool logEvents[12];
};

// ============================================================================
// GLOBAL OBJECTS
// ============================================================================
extern RTC_DS3231 rtc;
extern FeedMateWebServer webServer;
extern WiFiClient wifiClient;
extern PubSubClient mqttClient;
extern WiFiUDP ntpUDP;


// ============================================================================
// GLOBAL STATE
// ============================================================================
extern FeedMateConfig config;
constexpr uint8_t MAX_SCHEDULE_ENTRIES = 32;
extern FeedingSlot schedule[MAX_SCHEDULE_ENTRIES];
extern LogEntry eventLog[MAX_LOG_ENTRIES];
extern uint8_t logCount;
extern uint8_t logIndex;

extern bool motorRunning;
extern unsigned long motorStartTime;
extern unsigned long motorDuration;
extern bool jamActive;
extern unsigned long jamDetectedAt;
extern bool powerOnline;
extern unsigned long lastMqttPublish;
extern unsigned long lastScheduleCheck;
extern uint32_t rotationCount;
extern uint8_t foodLevelPercent;
extern bool isAuthenticated;
extern unsigned long lastAuthTime;

extern bool storageReady, clockValid, rtcPresent;
extern bool logsDirty;
extern String bootNonce;
extern String managementApSsid;
extern bool managementApStarted;
extern uint32_t managementApStarts, managementApFailures;
void setupLittleFS();
void loadConfig();
bool saveConfig();
void setDefaultConfig();
void loadSchedule();
bool saveSchedule();
void setDefaultSchedule();
void loadLogFromFile();
bool saveLogToFile();
void addLogEntry(uint8_t type, const char* message);
bool atomicJson(const char* path, const JsonDocument& doc);
void setupWiFi();
void startFallbackAP();
void serviceManagementAP();
void setupRTC();
void serviceClock();
uint32_t utcNow();
const char* timezoneRule(const char* zone);
bool timezoneSupported(const char* zone);
void setupWebServer();
void setupAuth();
String randomHex(size_t bytes);
void setupMQTT();
void serviceMQTT();
void publishMQTTStatus();
void checkSchedule();
bool estimateFood(const char* name,double grams,uint16_t& duration,uint8_t& target);
bool startMotor(uint16_t durationMs);
bool requestMotor(uint16_t durationMs);
bool requestMotor(uint16_t durationMs, uint8_t targetRotations);
void serviceMotorRequest();
void stopMotor(bool success = false, const char* reason = "Feeding aborted");
void serviceMotor();
bool resetFault();
void checkSensors();
void handleManualButton();
void checkPowerStatus();
#endif
