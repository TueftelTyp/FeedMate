# FeedMate v1.27

Der ESP32-Hostname wird vor dem ersten Wi-Fi-Moduswechsel gesetzt. Ohne gespeichertes Heimnetz startet die Firmware im reinen AP-Modus; AP+STA wird nur bei vorhandenen Router-Zugangsdaten verwendet. Die Heimnetzverbindung wartet, bis Setup-Clients getrennt sind.

Der Funkbetrieb muss auf der jeweiligen Platine geprüft werden; ein erfolgreicher Treiberstatus beweist keine tatsächliche Funkabstrahlung.