# FeedMate v1.26

v1.26 korrigiert den WLAN-Startablauf. Das Setup-AP wird gestartet, ohne danach
das Funkmodul mit `WIFI_OFF` auszuschalten. Eine bereits verbundene
Smartphone-Sitzung wird nicht mehr durch diese Neuinitialisierung getrennt.
Das gespeicherte Heimnetz wird erst gestartet, nachdem alle Setup-Clients
getrennt sind. Die AP-Überwachung lässt einen intakten AP unangetastet.

## Prüfung

- Vollständiger ESP8266-D1-mini-Firmwarebuild: bestanden.
- ESP32-C3-Build: hier durch Windows-Fehler 5 im GCC-Assembler blockiert; kein
  C++-Diagnosefehler.
- AP-Verhalten nach dem Flashen von v1.26 muss am konkreten Board bestätigt
  werden. Die Entwicklungsumgebung kann die Funkabstrahlung nicht nachweisen.
