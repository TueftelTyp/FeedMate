# FeedMate v1.19

v1.19 vereinfacht die vollständige Ersteinrichtung per Smartphone. Das FeedMate-Setup-WLAN verwendet das feste Kennwort `feedmate`, die Verwaltungsoberfläche initial `FeedMateAdmin`. Das Admin-Kennwort wird weiterhin nur als gerätespezifisch gesalzener SHA-256-Hash gespeichert und sollte nach der ersten Anmeldung geändert werden. Bereits konfigurierte persönliche Kennwörter bleiben bei einem Firmwareupdate erhalten. Der serielle Einmal-Wiederherstellungscode bleibt als Notfallweg verfügbar. Alle Boardprofile und Korrekturen aus v1.18 sind enthalten.
