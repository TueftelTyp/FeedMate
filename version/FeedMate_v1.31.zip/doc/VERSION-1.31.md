# FeedMate v1.31

Admin-Passwörter für Änderung und Wiederherstellung müssen mindestens 10 und höchstens 128 Zeichen haben. Gruppenschlüssel behalten eine Mindestlänge von 16 Zeichen.

Ein kurzer Tastendruck quittiert einen Motorfehler nur, wenn der Jam-Eingang nicht mehr aktiv ist. Der Tastendruck startet bei aktivem Fehler keinen Motor.