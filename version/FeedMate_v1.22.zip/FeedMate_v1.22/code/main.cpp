#include "config.h"
RTC_DS3231 rtc;
FeedMateWebServer webServer(80);
WiFiClient wifiClient;
PubSubClient mqttClient(wifiClient);
WiFiUDP ntpUDP;
bool motorRunning=false, jamActive=false, powerOnline=true;
unsigned long motorStartTime=0,motorDuration=0,jamDetectedAt=0,lastMqttPublish=0,lastScheduleCheck=0;
uint32_t rotationCount=0;
uint8_t foodLevelPercent=0;
bool isAuthenticated=false;
unsigned long lastAuthTime=0;
bool clockValid=false,rtcPresent=false;
String bootNonce;
static bool fallbackApStarted=false;
static uint32_t lastFallbackAttempt=0;

uint32_t utcNow() {
    time_t now=time(nullptr);
    return clockValid && now>=1704067200 && now<4102444800LL ? uint32_t(now):0;
}
void setupRTC() {
    Wire.begin(PIN_RTC_SDA,PIN_RTC_SCL);
    rtcPresent=rtc.begin();
    if(rtcPresent && !rtc.lostPower()) {
        DateTime now=rtc.now();
        if(now.isValid() && now.year()>=2024 && now.year()<2100) {
            timeval tv={time_t(now.unixtime()),0}; settimeofday(&tv,nullptr); clockValid=true;
        }
    }
    // RTC stores UTC. POSIX timezone rules affect schedules and display only.
#if defined(ESP32)
    configTzTime(config.timezone,"pool.ntp.org","time.nist.gov");
#else
    configTime(config.timezone,"pool.ntp.org","time.nist.gov");
#endif
}
void serviceClock() {
    time_t now=time(nullptr);
    if(now<1704067200 || now>=4102444800LL) { clockValid=false; return; }
    clockValid=true;
    static uint32_t last=0;
    if(rtcPresent && millis()-last>=60000) {
        last=millis();
        Wire.beginTransmission(0x68);
        if(Wire.endTransmission()!=0) { rtcPresent=false; return; }
        DateTime rtcTime=rtc.now();
        if(rtc.lostPower() || !rtcTime.isValid() || labs(long(now)-long(rtcTime.unixtime()))>2)
            rtc.adjust(DateTime(uint32_t(now)));
    }
}
void setupWiFi() {
#if defined(ESP32)
    WiFi.setHostname(WIFI_HOSTNAME);
#else
    WiFi.hostname(WIFI_HOSTNAME);
#endif
    WiFi.setAutoReconnect(true);
    if(config.wifiSsid[0]) WiFi.begin(config.wifiSsid,config.wifiPassword);
    else if(!fallbackApStarted) startFallbackAP();
}
void startFallbackAP() {
    lastFallbackAttempt=millis();
    WiFi.mode(WIFI_AP_STA);
    delay(100);
    String name=String("FeedMate-")+deviceId();
    fallbackApStarted=WiFi.softAP(name.c_str(),INITIAL_AP_PASSWORD);
    Serial.printf("Setup AP %s: %s Password: %s IP: %s\n",
                  fallbackApStarted?"started":"FAILED",name.c_str(),INITIAL_AP_PASSWORD,
                  WiFi.softAPIP().toString().c_str());
    // Give phones enough beacon time even if a later initialization step resets.
    if(fallbackApStarted) delay(2000);
}
void checkPowerStatus() {
    int raw=analogRead(PIN_POWER_SENSE);
    bool online=powerOnline ? raw>450 : raw>550;
    if(online!=powerOnline) { powerOnline=online; addLogEntry(online?EVT_POWER_RESTORED:EVT_POWER_OUTAGE,online?"Power restored":"Power outage"); }
}
void setup() {
    digitalWrite(PIN_MOTOR_GATE,LOW); pinMode(PIN_MOTOR_GATE,OUTPUT);
    Serial.begin(115200);
    // Make smartphone setup available before storage, authentication, RTC,
    // sensors or web-server initialization can fail.
    startFallbackAP();
#if defined(ESP32)
    analogReadResolution(10); // Shared raw ADC thresholds; calibrate actual divider.
    analogSetPinAttenuation(PIN_POWER_SENSE,ADC_11db);
#endif
    pinMode(PIN_JAM_SENSOR,INPUT_PULLUP); pinMode(PIN_LIGHT_BARRIER,INPUT);
    pinMode(PIN_HALL_SENSOR,INPUT); pinMode(PIN_MANUAL_BUTTON,INPUT_PULLUP);
    setupStatusLed();
    setupLittleFS(); loadConfig(); loadSchedule(); loadLogFromFile();
    bootNonce=randomHex(16); setupAuth(); setupWiFi(); setupRTC(); setupWebServer(); setupMQTT();
    addLogEntry(EVT_BOOT,"Boot; interrupted feeds are never resumed");
}
void loop() {
    serviceMotor(); checkSensors(); handleManualButton();
    // Synchronous network and flash operations are excluded while running.
    if(motorRunning) { platformIdle(); return; }
    serviceClock();
    webServer.handleClient();
    serviceMotorRequest();
    if(motorRunning) return;
    serviceMQTT();
    serviceMotorRequest();
    if(motorRunning) return;
    if(millis()-lastScheduleCheck>=1000) { lastScheduleCheck=millis(); checkSchedule(); }
    if(motorRunning) return;
    static uint32_t lastSlow=0;
    if(millis()-lastSlow>=5000) { lastSlow=millis(); checkPowerStatus(); if(logsDirty) saveLogToFile(); }
    bool needsFallback=!config.wifiSsid[0] || (millis()>30000 && WiFi.status()!=WL_CONNECTED);
    if(config.wifiSsid[0] && WiFi.status()==WL_CONNECTED && fallbackApStarted) {
        WiFi.softAPdisconnect(true); fallbackApStarted=false; WiFi.mode(WIFI_STA);
    }
    if(fallbackApStarted && WiFi.softAPIP()==IPAddress(0,0,0,0)) fallbackApStarted=false;
    if(needsFallback && !fallbackApStarted && millis()-lastFallbackAttempt>=5000) startFallbackAP();
    static uint32_t lastApReport=0;
    if(fallbackApStarted && millis()-lastApReport>=30000) {
        lastApReport=millis();
        Serial.printf("Setup AP active: FeedMate-%s IP: %s Clients: %u\n",
                      deviceId().c_str(),WiFi.softAPIP().toString().c_str(),
                      unsigned(WiFi.softAPgetStationNum()));
    }
    platformIdle();
}
