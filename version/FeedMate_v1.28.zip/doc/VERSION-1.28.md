# FeedMate v1.28

Standardziel ist `esp32c3_supermini`. Der C3 AP wird im reinen AP-Modus gestartet, sofern kein Heimnetz gespeichert ist. Die ESP32 AP-Sendeleistung wird explizit konfiguriert; tatsächlicher Beacon-Empfang muss auf der konkreten Platine gemessen werden.