# FeedMate v1.29

Konfigurationsfehler werden nach Feldursache gemeldet, damit unzulässige MQTT-, Zeitzonen- oder Portionswerte nicht mehr als allgemeiner Fehler erscheinen.