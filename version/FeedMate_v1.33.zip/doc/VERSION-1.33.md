# FeedMate v1.33

Speichern von WLAN, Gerätename/Hostname oder Zeitzone fragt, ob das Gerät danach neu starten soll. Ja: Konfiguration speichern und nach Übertragung der HTTP-Antwort selbst neu starten. Nein: speichern und eingeschaltet bleiben. Gruppenschlüssel: 16 bis 128 Zeichen; Admin-Passwörter: 10 bis 128 Zeichen.